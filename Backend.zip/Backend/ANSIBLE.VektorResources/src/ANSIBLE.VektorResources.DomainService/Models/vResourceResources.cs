﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ANSIBLE.VektorResources.DomainService
{
    public class ResourceResources
    {
        public List<string> CrewMembers { get; set; }
    }
}
