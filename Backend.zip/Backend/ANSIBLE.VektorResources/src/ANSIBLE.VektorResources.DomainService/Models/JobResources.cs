﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ANSIBLE.VektorResources.DomainService
{
    public class JobResources
    {
        public List<string> CrewMembers { get; set; }
    }
}
