﻿using Abp.Modules;
using ANSIBLE.ComponentBase;
using ANSIBLE.VektorResources.EntityFramework;
using System;

namespace ANSIBLE.VektorResources.DomainService
{
    [DependsOn(
        typeof(ComponentBaseCoreModule),
        typeof(VektorResourcesEFModule))]
    public class VektorResourcesDomainModule : ComponentBaseCoreModuleBase<VektorResourcesDomainModule>
    {
        public override void PreInitialize()
        {
            //base.PreInitialize();
        }
        public override void Initialize()
        {
            base.Initialize();
        }
    }
}
