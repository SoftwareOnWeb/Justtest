﻿using Abp.Domain.Repositories;
using Abp.Domain.Uow;
using ANSIBLE.ComponentBase;
using ANSIBLE.VektorResources.DomainEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ANSIBLE.VektorResources.DomainService
{
    public class ResourceManager : ComponentBaseDomainService, IResourceManager
    {
        private readonly IRepository<Resource, long> _resourceRepository;

        public ResourceManager(IRepository<Resource, long> resourceRepository)
        {
            _resourceRepository = resourceRepository;
        }

        public async Task<Resource> GetResource(long resourceId)
        {
            return await _resourceRepository.GetAsync(resourceId);
        }
        // public async Task<List<Resource>> GetResourceAll()
        //{
        //   // return await _resourceRepository.GetAllIncluding(r => r.ResourceType).Where(r => string.IsNullOrEmpty(ResourceTypeName) || r.ResourceType.Name == ResourceTypeName).ToListAsync();
        //      return await _resourceRepository.GetAllIncluding(r => r.ResourceType).ToListAsync();
        //}
        public async Task<List<Resource>> GetResources(long resourceTypeId)
        {
            return await _resourceRepository.GetAllIncluding(r=>r.ResourceType).Where(r => resourceTypeId == 0 || r.ResourceTypeId == resourceTypeId).ToListAsync();
            //  return await _resourceRepository.GetAllListAsync();
        }

       
        //public async Task<List<Resource>> GetResourceList(string ResourceTypeName)
        //{
        //    return await _resourceRepository.GetAll().Where(r => r.ResourceType.Name == ResourceTypeName).ToListAsync();


        //   //  return await _resourceRepository.GetAllListAsync();
        //    //return await _resourceRepository.GetAll().Include(r => r.ResourceType).ToListAsync();
        //    // return await _resourceRepository.GetAll().Include(r => r.ResourceType).ToListAsync();
        //}

        [UnitOfWork]
        public async Task<Resource> CreateResource(Resource resource)
        {
            var createdresource = await _resourceRepository.InsertAsync(resource);
            await CurrentUnitOfWork.SaveChangesAsync();

            return createdresource;
        }

        [UnitOfWork]
        public async Task<Resource> UpdateResource(Resource resource)
        {
            var updatedresource = await _resourceRepository.UpdateAsync(resource);
            await CurrentUnitOfWork.SaveChangesAsync();

            return updatedresource;
        }

        //#region workflow_methods
        //[UnitOfWork]
        //public async Task<Resource> Abandonresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);
        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Abandon();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Acknowledgeresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Acknowledge();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> AproveresourceForBilling(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.AproveForBilling();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Assignresource(long resourceId, ResourceResources resourceResources)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Assign(resourceResources);

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Billresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Bill();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Cancelresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Cancel();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Completeresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Complete();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Expireresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Expire();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> NotAcknowledgeresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.NotAcknowledge();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Pauseresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Pause();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Resumeresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Resume();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Startresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Start();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

      

        //#endregion

    }
}
