﻿using Abp.Domain.Services;
using ANSIBLE.ComponentBase;
using ANSIBLE.VektorResources.DomainEntity;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ANSIBLE.VektorResources.DomainService
{
    public interface IResourceTypeManager : IComponentBaseDomainService
    {
        Task<ResourceType> GetResourceType(long resourceTypeId, string name);
        Task<List<ResourceType>> GetResourceTypes();
       // Task<List<ResourceType>> GetResourceTypeAll();
        Task<ResourceType> CreateResourceType(ResourceType resourceType);
        Task<ResourceType> UpdateResourceType(ResourceType resourceType);
        /* workflow_methods
        #region workflow_methods
        Task<Job> AssignJob(long jobId, JobResources jobResources);

        Task<Job> CancelJob(long jobId);

        Task<Job> AcknowledgeJob(long jobId);

        Task<Job> NotAcknowledgeJob(long jobId);

        Task<Job> StartJob(long jobId);

        Task<Job> ExpireJob(long jobId);

        Task<Job> CompleteJob(long jobId);

        Task<Job> AbandonJob(long jobId);

        Task<Job> PauseJob(long jobId);

        Task<Job> ResumeJob(long jobId);

        Task<Job> AproveJobForBilling(long jobId);

        Task<Job> BillJob(long jobId);

        #endregion
        */
    }
}
