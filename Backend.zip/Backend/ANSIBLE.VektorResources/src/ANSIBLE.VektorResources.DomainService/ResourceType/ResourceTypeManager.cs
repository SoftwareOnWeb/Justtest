﻿using Abp.Domain.Repositories;
using Abp.Domain.Uow;
using ANSIBLE.ComponentBase;
using ANSIBLE.VektorResources.DomainEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace ANSIBLE.VektorResources.DomainService
{
    public class ResourceTypeManager : ComponentBaseDomainService, IResourceTypeManager
    {
        private readonly IRepository<ResourceType, long> _resourceTypeRepository;

        public ResourceTypeManager(IRepository<ResourceType, long> resourceTypeRepository)
        {
            _resourceTypeRepository = resourceTypeRepository;
        }

        public async Task<ResourceType> GetResourceType(long resourceTypeId, string name)
        {
            if (resourceTypeId>0)
            {
                 return await _resourceTypeRepository.GetAsync(resourceTypeId);
            }
            else
            {
                var rt= await _resourceTypeRepository.GetAllIncluding().Where(r =>  r.Name == name).FirstOrDefaultAsync();
                //if (rt==null)
                //{
                //    throw new Exception("No resource Type was found for name:"+name);
                //}
                return rt;
            }



            //return await _resourceTypeRepository.GetAllIncluding().Where(
            //                                                               r => (resourceTypeId == 0 || r.Id == resourceTypeId)
            //                                                               && (string.IsNullOrEmpty(name) || r.Name == name)

            //                                                           ).FirstOrDefaultAsync()

            //  return await _resourceTypeRepository.ge;
        }
        public async Task<List<ResourceType>> GetResourceTypes()
        {
            // return await _resourceTypeRepository.GetAllIncluding().Where(r => string.IsNullOrEmpty(name) || r.Name == name).ToListAsync();
            return await _resourceTypeRepository.GetAllListAsync();
        }


        [UnitOfWork]
        public async Task<ResourceType> CreateResourceType(ResourceType resourceType)
        {
            var createdresourceType = await _resourceTypeRepository.InsertAsync(resourceType);
            await CurrentUnitOfWork.SaveChangesAsync();

            return createdresourceType;
        }

        [UnitOfWork]
        public async Task<ResourceType> UpdateResourceType(ResourceType resourceType)
        {
            var updatedresourceType = await _resourceTypeRepository.UpdateAsync(resourceType);
            await CurrentUnitOfWork.SaveChangesAsync();

            return updatedresourceType;
        }

        //#region workflow_methods
        //[UnitOfWork]
        //public async Task<ResourceType> Abandonresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);
        //    var stateManager = new ResourceTypeStateManager(resource);
        //    stateManager.Abandon();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Acknowledgeresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Acknowledge();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> AproveresourceForBilling(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.AproveForBilling();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Assignresource(long resourceId, ResourceResources resourceResources)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Assign(resourceResources);

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Billresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Bill();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Cancelresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Cancel();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Completeresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Complete();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Expireresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Expire();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> NotAcknowledgeresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.NotAcknowledge();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Pauseresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Pause();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Resumeresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Resume();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}

        //[UnitOfWork]
        //public async Task<Resource> Startresource(long resourceId)
        //{
        //    var resource = await _resourceRepository.GetAsync(resourceId);

        //    var stateManager = new ResourceStateManager(resource);
        //    stateManager.Start();

        //    _resourceRepository.Update(resource);
        //    await CurrentUnitOfWork.SaveChangesAsync();

        //    return resource;
        //}



        //#endregion

    }
}
