﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ANSIBLE.VektorResources.DomainService
{
    public class WorkflowException : Exception
    {

        public WorkflowException(string message)
            : base(message)
        {
        }
        public WorkflowException(string message, Exception ex)
            : base(message, ex)
        {
        }
        public static WorkflowException GetException(Exception ex, string title)
        {
            if (ex.Message.Contains("No valid leaving transitions are permitted from state"))
                return new WorkflowException($"{title} state cannot be changed!");
            throw new WorkflowException("Workflow Unknown Exception", ex);
        }
    }
}
