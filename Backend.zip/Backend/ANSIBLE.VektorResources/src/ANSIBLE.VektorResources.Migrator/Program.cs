﻿using System;
using Abp;
using Abp.Collections.Extensions;
using Abp.Dependency;
using Castle.Facilities.Logging;
using Abp.Castle.Logging.Log4Net;
using ANSIBLE.ComponentBase.Migrator;

namespace ANSIBLE.VektorResources.Migrator
{
    public class Program
    {
        public static void Main(string[] args)
        {
            ANSIBLE.ComponentBase.Migrator.Program.Main<VektorResourcesMigratorModule>(args);
        }
    }
}
