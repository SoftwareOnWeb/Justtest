using Abp.Modules;
using Microsoft.Extensions.Configuration;
using ANSIBLE.VektorResources.EntityFramework;

namespace ANSIBLE.ComponentBase.Migrator
{
    [DependsOn(typeof(VektorResourcesEFModule))]
    public class VektorResourcesMigratorModule : ComponentBaseMigratorModule<VektorResourcesMigratorModule, VektorResourcesEFModule>
    {
        public VektorResourcesMigratorModule(VektorResourcesEFModule abpProjectNameEntityFrameworkModule)
            : base(abpProjectNameEntityFrameworkModule)
        {
        }

        public override void PreInitialize()
        {
            Configuration.DefaultNameOrConnectionString = appConfiguration.GetConnectionString(
                typeof(VektorResourcesDbContext).FullName);
        }
    }
}