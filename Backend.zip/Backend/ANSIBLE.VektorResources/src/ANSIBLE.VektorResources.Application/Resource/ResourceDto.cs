﻿using Abp.AutoMapper;
using ANSIBLE.ComponentBase;
using ANSIBLE.VektorResources.DomainEntity;
using Newtonsoft.Json;
using SalDotnetServiceSajd.Json.Converters;
using System;
using System.ComponentModel.DataAnnotations;

namespace ANSIBLE.VektorResources.Dto
{

    [AutoMap(typeof(Resource))]
    public class ResourceDto : ResourceListDto
    {
        public ResourceTypeDto ResourceType { get; set; }
    }

    [AutoMap(typeof(Resource))]
    public class ResourceListDto : DtoBase<long>
    {
        //  public long Id { get; set; }
        public string Identifier { get; set; }
        public string Description { get; set; }
        [Required]
        public long? ResourceTypeId { get; set; }
        public string BaseOfOperation { get; set; }

        public string LastState { get; set; }
        public string LastLocation { get; set; }
        public string AditionalFields { get; set; }
    }

}
