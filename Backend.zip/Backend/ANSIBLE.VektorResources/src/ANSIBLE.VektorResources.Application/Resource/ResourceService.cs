﻿using Abp.Application.Services.Dto;
using Abp.Runtime.Session;
using ANSIBLE.ComponentBase;
using ANSIBLE.VektorResources.DomainService;
using ANSIBLE.VektorResources.Dto;
using ANSIBLE.VektorResources.DomainEntity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ANSIBLE.VektorResources.Application
{
    public class ResourceService : ComponentBaseAppServiceBase, IResourceService
    {
        private readonly IResourceManager _resourceManager;

        public ResourceService(IResourceManager resourceManager)
        {
            _resourceManager = resourceManager;
          //  AbpSession = NullAbpSession.Instance;
        }

        //todo: it should be checked if an specific permission needed for this service 
        //[AbpAuthorize(AppPermissions.??)]
        public async Task<ResourceDto> GetResource(long resourceId)
        {
            var resource = await _resourceManager.GetResource(resourceId);
           
            var tId = AbpSession.TenantId;
            return ObjectMapper.Map<ResourceDto>(resource);
        }
        //public async Task<ListResultDto<ResourceDto>> GetResourceAll()
        //{
        //    var resourceList = await _resourceManager.GetResourceAll();
        //    return new ListResultDto<ResourceDto>(ObjectMapper.Map<List<ResourceDto>>(resourceList));
        //}
        public async Task<ListResultDto<ResourceListDto>> GetResources(long resourceTypeId)
        {
            var resourceList = await _resourceManager.GetResources(resourceTypeId);
            return new ListResultDto<ResourceListDto>(ObjectMapper.Map<List<ResourceListDto>>(resourceList));
        }
        //public async Task<ListResultDto<ResourceDto>> GetResourceList(String ResourceTypeName)
        //{
        //    var resourceList = await _resourceManager.GetResourceList( ResourceTypeName);
        //    return new ListResultDto<ResourceDto>(ObjectMapper.Map<List<ResourceDto>>(resourceList));
        //}

        public async Task<ResourceDto> CreateOrUpdateResource(ResourceDto input)
        {
            var resource = ObjectMapper.Map<Resource>(input);
            //var resourceResources = input.resourceResources;
            if (input.Id == 0)
            {
                var createdresource = await _resourceManager.CreateResource(resource);
                //if (resourceResources != null)
                //    await _resourceManager.Assignresource(createdresource.Id, resourceResources);
                return ObjectMapper.Map<ResourceDto>(createdresource);
            }
            else
            {
                var updatedresource = await _resourceManager.UpdateResource(resource);
                //if (resourceResources != null)
                //    await _resourceManager.Assignresource(updatedresource.Id, resourceResources);
                return ObjectMapper.Map<ResourceDto>(updatedresource);
            }
        }


        /* workflow_methods
        #region workflow_methods
        public async Task<resourceDto> Abandonresource(long resourceId)
        {
            var resource = await _resourceManager.Abandonresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Acknowledgeresource(long resourceId)
        {
            var resource = await _resourceManager.Acknowledgeresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> AproveresourceForBilling(long resourceId)
        {
            var resource = await _resourceManager.AproveresourceForBilling(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Assignresource(long resourceId, resourceResources resourceResources)
        {
            var resource = await _resourceManager.Assignresource(resourceId, resourceResources);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Billresource(long resourceId)
        {
            var resource = await _resourceManager.Billresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Cancelresource(long resourceId)
        {
            var resource = await _resourceManager.Cancelresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Completeresource(long resourceId)
        {
            var resource = await _resourceManager.Completeresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Expireresource(long resourceId)
        {
            var resource = await _resourceManager.Expireresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> NotAcknowledgeresource(long resourceId)
        {
            var resource = await _resourceManager.NotAcknowledgeresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Pauseresource(long resourceId)
        {
            var resource = await _resourceManager.Pauseresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Resumeresource(long resourceId)
        {
            var resource = await _resourceManager.Resumeresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Startresource(long resourceId)
        {
            var resource = await _resourceManager.Startresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }
        #endregion
        */
    }
}
