﻿using Abp.Application.Services.Dto;
using ANSIBLE.ComponentBase;
using ANSIBLE.VektorResources.Dto;
using System.Threading.Tasks;

namespace ANSIBLE.VektorResources.Application
{
    public interface IResourceService : IComponentBaseAppService
    {
        Task<ResourceDto> GetResource(long resourceId);

        //Task<ListResultDto<ResourceDto>> GetResourceAll();
        Task<ListResultDto<ResourceListDto>> GetResources(long resourceTypeId);

        Task<ResourceDto> CreateOrUpdateResource(ResourceDto input);

        /* workflow_methods
        #region workflow_methods

        Task<JobDto> AssignJob(long jobId, JobResources jobResources);

        Task<JobDto> CancelJob(long jobId);

        Task<JobDto> AcknowledgeJob(long jobId);

        Task<JobDto> NotAcknowledgeJob(long jobId);

        Task<JobDto> StartJob(long jobId);

        Task<JobDto> ExpireJob(long jobId);

        Task<JobDto> CompleteJob(long jobId);

        Task<JobDto> AbandonJob(long jobId);

        Task<JobDto> PauseJob(long jobId);

        Task<JobDto> ResumeJob(long jobId);

        Task<JobDto> AproveJobForBilling(long jobId);

        Task<JobDto> BillJob(long jobId);
        #endregion
        */
    }
}
