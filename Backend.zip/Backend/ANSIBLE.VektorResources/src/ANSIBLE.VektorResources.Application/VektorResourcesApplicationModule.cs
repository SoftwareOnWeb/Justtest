﻿using Abp.Modules;
using ANSIBLE.ComponentBase;
using ANSIBLE.VektorResources.DomainService;

namespace ANSIBLE.VektorResources.Application
{
    [DependsOn(
        typeof(ComponentBaseApplicationModule),
        typeof(VektorResourcesDomainModule))]
    public class VektorResourcesApplicationModule : ComponentBaseApplicationModuleBase<VektorResourcesApplicationModule>
    {
        public override void PreInitialize()
        {
            base.PreInitialize();
            /*
            Configuration.Modules.AbpAutoMapper().Configurators.Add(config =>
            {
                config.CreateMap<JobDto, Job>()
            //          .ForMember(u => u.AditionalFields, 
            //            options => options.MapFrom(input => input.JobResources))
            ;
            });
            */
        }
        public override void Initialize()
        {
            base.Initialize();
        }
    }
}