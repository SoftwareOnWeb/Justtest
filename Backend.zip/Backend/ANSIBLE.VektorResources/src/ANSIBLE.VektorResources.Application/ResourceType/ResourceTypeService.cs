﻿using Abp.Application.Services.Dto;
using Abp.Runtime.Session;
using ANSIBLE.ComponentBase;
using ANSIBLE.VektorResources.DomainService;
using ANSIBLE.VektorResources.Dto;
using ANSIBLE.VektorResources.DomainEntity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ANSIBLE.VektorResources.Application
{
    public class ResourceTypeService : ComponentBaseAppServiceBase, IResourceTypeService
    {
        private readonly IResourceTypeManager _resourceManager;

        public ResourceTypeService(IResourceTypeManager resourceManager)
        {
            _resourceManager = resourceManager;
          //  AbpSession = NullAbpSession.Instance;
        }

        //todo: it should be checked if an specific permission needed for this service 
        //[AbpAuthorize(AppPermissions.??)]
        public async Task<ResourceTypeDto> GetResourceType(long resourceTypeId, string name)
        {
            var resource = await _resourceManager.GetResourceType(resourceTypeId, name);
           
            var tId = AbpSession.TenantId;
            return ObjectMapper.Map<ResourceTypeDto>(resource);
        }
        //public async Task<ListResultDto<ResourceTypeDto>> GetResourceTypeAll()
        //{
        //    var resourceList = await _resourceManager.GetResourceTypeAll();
        //    return new ListResultDto<ResourceTypeDto>(ObjectMapper.Map<List<ResourceTypeDto>>(resourceList));
        //}
        public async Task<ListResultDto<ResourceTypeDto>> GetResourceTypes()
        {
            var resourceList = await _resourceManager.GetResourceTypes();
            return new ListResultDto<ResourceTypeDto>(ObjectMapper.Map<List<ResourceTypeDto>>(resourceList));
        }
        //public async Task<ListResultDto<ResourceTypeDto>> GetResourceTypeList(String ResourceTypeTypeName)
        //{
        //    var resourceList = await _resourceManager.GetResourceTypeList( ResourceTypeTypeName);
        //    return new ListResultDto<ResourceTypeDto>(ObjectMapper.Map<List<ResourceTypeDto>>(resourceList));
        //}

        public async Task<ResourceTypeDto> CreateOrUpdateResourceType(ResourceTypeDto input)
        {
            var resourceType = ObjectMapper.Map<ResourceType>(input);
            //var resourceResourceTypes = input.resourceResourceTypes;
            if (input.Id == 0)
            {
                var createdresourceType = await _resourceManager.CreateResourceType(resourceType);
                //if (resourceResourceTypes != null)
                //    await _resourceManager.Assignresource(createdresource.Id, resourceResourceTypes);
                return ObjectMapper.Map<ResourceTypeDto>(createdresourceType);
            }
            else
            {
                var updatedresourceType = await _resourceManager.UpdateResourceType(resourceType);
                //if (resourceResourceTypes != null)
                //    await _resourceManager.Assignresource(updatedresource.Id, resourceResourceTypes);
                return ObjectMapper.Map<ResourceTypeDto>(updatedresourceType);
            }
        }


        /* workflow_methods
        #region workflow_methods
        public async Task<resourceDto> Abandonresource(long resourceId)
        {
            var resource = await _resourceManager.Abandonresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Acknowledgeresource(long resourceId)
        {
            var resource = await _resourceManager.Acknowledgeresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> AproveresourceForBilling(long resourceId)
        {
            var resource = await _resourceManager.AproveresourceForBilling(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Assignresource(long resourceId, resourceResourceTypes resourceResourceTypes)
        {
            var resource = await _resourceManager.Assignresource(resourceId, resourceResourceTypes);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Billresource(long resourceId)
        {
            var resource = await _resourceManager.Billresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Cancelresource(long resourceId)
        {
            var resource = await _resourceManager.Cancelresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Completeresource(long resourceId)
        {
            var resource = await _resourceManager.Completeresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Expireresource(long resourceId)
        {
            var resource = await _resourceManager.Expireresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> NotAcknowledgeresource(long resourceId)
        {
            var resource = await _resourceManager.NotAcknowledgeresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Pauseresource(long resourceId)
        {
            var resource = await _resourceManager.Pauseresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Resumeresource(long resourceId)
        {
            var resource = await _resourceManager.Resumeresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }

        public async Task<resourceDto> Startresource(long resourceId)
        {
            var resource = await _resourceManager.Startresource(resourceId);
            return ObjectMapper.Map<resourceDto>(resource);
        }
        #endregion
        */
    }
}
