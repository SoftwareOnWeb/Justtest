﻿using Abp.AutoMapper;
using ANSIBLE.ComponentBase;
using ANSIBLE.VektorResources.DomainEntity;
using Newtonsoft.Json;
using SalDotnetServiceSajd.Json.Converters;
using System;
using System.ComponentModel.DataAnnotations;

namespace ANSIBLE.VektorResources.Dto
{

    [AutoMap(typeof(ResourceType))]
    public class VResourceTypeDto : DtoBase<long>
    {
        //public string id { get; set; }
        public string Name { get; set; }
        public bool IsBillable { get; set; }
        public bool HasSiteLocation { get; set; }
        public bool HasBaseOfOperation { get; set; }
        public bool AllowParentResourceTypes { get; set; }
        public bool AllowChildrenResourceTypes { get; set; }
        public bool AllowJobTypes { get; set; }
        public string AditionalFields { get; set; }
    }


    [AutoMap(typeof(Resource))]
    public class VResourceDto : DtoBase<long>
    {
      //  public long Id { get; set; }
        public string Identifier { get; set; }
        public string Description { get; set; }
        public VResourceTypeDto VResourceType { get; set; }
        [Required]
        public long? VResourceTypeId { get; set; }
        public bool BaseOfOperation { get; set; }
        public string LastState { get; set; }
        public string LastLocation { get; set; }
        public string AditionalFields { get; set; }
    }
}
