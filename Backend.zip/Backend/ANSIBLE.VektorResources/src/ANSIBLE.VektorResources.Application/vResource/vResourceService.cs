﻿using Abp.Application.Services.Dto;
using Abp.Runtime.Session;
using ANSIBLE.ComponentBase;
using ANSIBLE.VektorResources.DomainService;
using ANSIBLE.VektorResources.Dto;
using ANSIBLE.VektorResources.DomainEntity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ANSIBLE.VektorResources.Application
{
    public class VResourceService : ComponentBaseAppServiceBase, IVResourceService
    {
        private readonly IVResourceManager _vResourceManager;

        public VResourceService(IVResourceManager vResourceManager)
        {
            _vResourceManager = vResourceManager;
          //  AbpSession = NullAbpSession.Instance;
        }

        //todo: it should be checked if an specific permission needed for this service 
        //[AbpAuthorize(AppPermissions.??)]
        public async Task<VResourceDto> GetvResource(long vResourceId)
        {
            var vResource = await _vResourceManager.GetvResource(vResourceId);
           
            var tId = AbpSession.TenantId;
            return ObjectMapper.Map<VResourceDto>(vResource);
        }
        public async Task<ListResultDto<VResourceDto>> GetvResourceAll()
        {
            var vResourceList = await _vResourceManager.GetvResourceAll();
            return new ListResultDto<VResourceDto>(ObjectMapper.Map<List<VResourceDto>>(vResourceList));
        }
        public async Task<ListResultDto<VResourceDto>> GetvResourceList(String ResourceTypeName)
        {
            var vResourceList = await _vResourceManager.GetvResourceList(ResourceTypeName);
            return new ListResultDto<VResourceDto>(ObjectMapper.Map<List<VResourceDto>>(vResourceList));
        }
        //public async Task<ListResultDto<VResourceDto>> GetvResourceList(String ResourceTypeName)
        //{
        //    var vResourceList = await _vResourceManager.GetvResourceList( ResourceTypeName);
        //    return new ListResultDto<VResourceDto>(ObjectMapper.Map<List<VResourceDto>>(vResourceList));
        //}

        public async Task<VResourceDto> CreateOrUpdatevResource(VResourceDto input)
        {
            var vResource = ObjectMapper.Map<Resource>(input);
            //var vResourceResources = input.vResourceResources;
            if (input.Id == 0)
            {
                var createdvResource = await _vResourceManager.CreatevResource(vResource);
                //if (vResourceResources != null)
                //    await _vResourceManager.AssignvResource(createdvResource.Id, vResourceResources);
                return ObjectMapper.Map<VResourceDto>(createdvResource);
            }
            else
            {
                var updatedvResource = await _vResourceManager.UpdatevResource(vResource);
                //if (vResourceResources != null)
                //    await _vResourceManager.AssignvResource(updatedvResource.Id, vResourceResources);
                return ObjectMapper.Map<VResourceDto>(updatedvResource);
            }
        }


        /* workflow_methods
        #region workflow_methods
        public async Task<vResourceDto> AbandonvResource(long vResourceId)
        {
            var vResource = await _vResourceManager.AbandonvResource(vResourceId);
            return ObjectMapper.Map<vResourceDto>(vResource);
        }

        public async Task<vResourceDto> AcknowledgevResource(long vResourceId)
        {
            var vResource = await _vResourceManager.AcknowledgevResource(vResourceId);
            return ObjectMapper.Map<vResourceDto>(vResource);
        }

        public async Task<vResourceDto> AprovevResourceForBilling(long vResourceId)
        {
            var vResource = await _vResourceManager.AprovevResourceForBilling(vResourceId);
            return ObjectMapper.Map<vResourceDto>(vResource);
        }

        public async Task<vResourceDto> AssignvResource(long vResourceId, vResourceResources vResourceResources)
        {
            var vResource = await _vResourceManager.AssignvResource(vResourceId, vResourceResources);
            return ObjectMapper.Map<vResourceDto>(vResource);
        }

        public async Task<vResourceDto> BillvResource(long vResourceId)
        {
            var vResource = await _vResourceManager.BillvResource(vResourceId);
            return ObjectMapper.Map<vResourceDto>(vResource);
        }

        public async Task<vResourceDto> CancelvResource(long vResourceId)
        {
            var vResource = await _vResourceManager.CancelvResource(vResourceId);
            return ObjectMapper.Map<vResourceDto>(vResource);
        }

        public async Task<vResourceDto> CompletevResource(long vResourceId)
        {
            var vResource = await _vResourceManager.CompletevResource(vResourceId);
            return ObjectMapper.Map<vResourceDto>(vResource);
        }

        public async Task<vResourceDto> ExpirevResource(long vResourceId)
        {
            var vResource = await _vResourceManager.ExpirevResource(vResourceId);
            return ObjectMapper.Map<vResourceDto>(vResource);
        }

        public async Task<vResourceDto> NotAcknowledgevResource(long vResourceId)
        {
            var vResource = await _vResourceManager.NotAcknowledgevResource(vResourceId);
            return ObjectMapper.Map<vResourceDto>(vResource);
        }

        public async Task<vResourceDto> PausevResource(long vResourceId)
        {
            var vResource = await _vResourceManager.PausevResource(vResourceId);
            return ObjectMapper.Map<vResourceDto>(vResource);
        }

        public async Task<vResourceDto> ResumevResource(long vResourceId)
        {
            var vResource = await _vResourceManager.ResumevResource(vResourceId);
            return ObjectMapper.Map<vResourceDto>(vResource);
        }

        public async Task<vResourceDto> StartvResource(long vResourceId)
        {
            var vResource = await _vResourceManager.StartvResource(vResourceId);
            return ObjectMapper.Map<vResourceDto>(vResource);
        }
        #endregion
        */
    }
}
