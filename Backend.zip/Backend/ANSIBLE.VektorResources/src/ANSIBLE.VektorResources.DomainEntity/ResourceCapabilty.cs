﻿using Abp.AutoMapper;
using Abp.Domain.Entities.Auditing;
using ANSIBLE.ComponentBase.DomainEntity;
using System;
using System.ComponentModel.DataAnnotations.Schema;


namespace ANSIBLE.VektorResources.DomainEntity
{
    public enum Capability : byte
    {
        Heavy_Skip_Transport = 1, 
        PrimeMover
    }

    [Table("Resource", Schema = VektorResourcesDomainEntityConst.DEFAULT_SCHEMA)]
    [AutoMap]
    public class ResourceCapability : EntityBase
    {
        public ResourceCapability()
        {
        }

        //   public string Id { get; set; }
        public string ResourceId { get; set; }
        public string CapabilityID { get; set; }
        public Capability Requires { get; set; }
        public Capability Provides { get; set; }
    }
}
