﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ANSIBLE.VektorResources.DomainEntity
{
    public class VektorResourcesDomainEntityConst
    {
        public const string DEFAULT_SCHEMA = "VektorResources";
        public const string DEFAULT_PREFIX = "";
    }
}
