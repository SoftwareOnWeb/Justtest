﻿using ANSIBLE.ComponentBase.DomainEntity;
using System.ComponentModel.DataAnnotations.Schema;

namespace ANSIBLE.VektorResources.DomainEntity
{
    [Table("ResourceType", Schema = VektorResourcesDomainEntityConst.DEFAULT_SCHEMA)]
    public class ResourceType : EntityBase
    {
        //public string id { get; set; }
        public string Name { get; set; }
        public bool IsBillable { get; set; }
        public bool HasSiteLocation { get; set; }
        public bool HasBaseOfOperation { get; set; }
        public bool AllowParentResourceTypes { get; set; }
        public bool AllowChildrenResourceTypes { get; set; }
        public bool AllowJobTypes { get; set; }
        public string AditionalFields { get; set; }
    }
}
