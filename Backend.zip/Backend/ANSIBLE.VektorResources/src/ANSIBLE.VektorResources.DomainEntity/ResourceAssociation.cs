﻿using ANSIBLE.ComponentBase.DomainEntity;
using System.ComponentModel.DataAnnotations.Schema;

namespace ANSIBLE.VektorResources.DomainEntity
{

    public enum ResourceRelationshipType : byte
    {
        PARENT = 1,
        CHILD
    }
    [Table("ResourceAssociation", Schema = VektorResourcesDomainEntityConst.DEFAULT_SCHEMA)]
    public class ResourceAssociation : EntityBase
    {
        //public string id { get; set; }
        public string SourceIdentifier { get; set; }
        public string TargetIdentifier { get; set; }
        public ResourceRelationshipType ResourceRelationshipType { get; set; }

    }
}
