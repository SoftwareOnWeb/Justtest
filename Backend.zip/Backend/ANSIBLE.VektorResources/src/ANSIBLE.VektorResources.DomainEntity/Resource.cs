﻿using Abp.AutoMapper;
using Abp.Domain.Entities.Auditing;
using ANSIBLE.ComponentBase.DomainEntity;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace ANSIBLE.VektorResources.DomainEntity
{
    //public enum ResourcePriority : byte
    //{
    //    NORMAL = 1,
    //    URGENT
    //}
    //public enum ResourceResolution : byte
    //{
    //    CLOSED = 1,
    //    ABONDANED
    //}
    //public enum ResourceStatus : byte
    //{
    //    resource_OPEN = 1, //Has been accepted and should be allocated
    //    resource_ASSIGNED,
    //    resource_ACKNOWLEDGED,
    //    resource_IN_PROGRESS,
    //    resource_IN_HOLD,
    //    resource_EXPIRED,
    //    resource_ABANDONED,
    //    resource_COMPLETED,
    //    resource_APPROVED_FOR_BILLING,
    //    resource_CANCELLED,
    //    resource_BILLED
    //}

    [Table("Resource", Schema = VektorResourcesDomainEntityConst.DEFAULT_SCHEMA)]

    public class Resource : EntityBase
    {
        public string Identifier { get; set; }
        public string Description { get; set; }
        public ResourceType ResourceType { get; set; }
        [Required]
        public long ResourceTypeId { get; set; }
        public string BaseOfOperation { get; set; }
        public string LastState { get; set; }
        public String LastLocation { get; set; }
        public string AditionalFields { get; set; }
        //public void SetAditionalFields(JObject obj)
        //{
        //    if (obj != null)
        //        this.AditionalFields = obj.ToString();
        //    else
        //        this.AditionalFields = null;
        //}
    }
}
