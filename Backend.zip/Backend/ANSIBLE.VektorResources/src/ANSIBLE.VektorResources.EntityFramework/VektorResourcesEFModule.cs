﻿using Abp.EntityFrameworkCore.Configuration;
using Abp.Modules;
using ANSIBLE.ComponentBase.EntityFrameworkCore;

namespace ANSIBLE.VektorResources.EntityFramework
{
    [DependsOn(
        typeof(ComponentBaseEntityFrameworkModule)
        )]
    public class VektorResourcesEFModule : ComponentBaseEntityFrameworkModuleBase<VektorResourcesEFModule>
    {
        public override void PreInitialize()
        {
            base.PreInitialize();
            if (!SkipDbContextRegistration)
            {
                Configuration.Modules.AbpEfCore().AddDbContext<VektorResourcesDbContext>(options =>
                {
                    if (options.ExistingConnection != null)
                    {
                        ComponentBaseDbContextConfigurer<VektorResourcesDbContext>.Configure(options.DbContextOptions, options.ExistingConnection);
                    }
                    else
                    {
                        ComponentBaseDbContextConfigurer<VektorResourcesDbContext>.Configure(options.DbContextOptions, options.ConnectionString);
                    }
                });
            }
        }
        public override void Initialize()
        {
            base.Initialize();
        }
    }
}