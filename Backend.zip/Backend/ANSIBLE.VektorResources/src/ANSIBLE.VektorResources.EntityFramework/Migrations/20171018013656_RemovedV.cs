﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace ANSIBLE.VektorResources.EntityFramework.Migrations
{
    public partial class RemovedV : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "vResource",
                schema: "VektorResources");

            migrationBuilder.DropTable(
                name: "vResourceType",
                schema: "VektorResources");

            migrationBuilder.CreateTable(
                name: "ResourceType",
                schema: "VektorResources",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AditionalFields = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AllowChildrenResourceTypes = table.Column<bool>(type: "bit", nullable: false),
                    AllowJobTypes = table.Column<bool>(type: "bit", nullable: false),
                    AllowParentResourceTypes = table.Column<bool>(type: "bit", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HasBaseOfOperation = table.Column<bool>(type: "bit", nullable: false),
                    HasSiteLocation = table.Column<bool>(type: "bit", nullable: false),
                    IsBillable = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ModifierUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TenantId = table.Column<int>(type: "int", nullable: false),
                    ValidFrom = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ValidUntil = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ResourceType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Resource",
                schema: "VektorResources",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AditionalFields = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BaseOfOperation = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatorUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Identifier = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false),
                    LastLocation = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime2", nullable: true),
                    LastState = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ModifierUser = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TenantId = table.Column<int>(type: "int", nullable: false),
                    VResourceTypeId = table.Column<long>(type: "bigint", nullable: false),
                    ValidFrom = table.Column<DateTime>(type: "datetime2", nullable: true),
                    ValidUntil = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Resource", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Resource_ResourceType_VResourceTypeId",
                        column: x => x.VResourceTypeId,
                        principalSchema: "VektorResources",
                        principalTable: "ResourceType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Resource_VResourceTypeId",
                schema: "VektorResources",
                table: "Resource",
                column: "VResourceTypeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Resource",
                schema: "VektorResources");

            migrationBuilder.DropTable(
                name: "ResourceType",
                schema: "VektorResources");

            migrationBuilder.CreateTable(
                name: "vResourceType",
                schema: "VektorResources",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AditionalFields = table.Column<string>(nullable: true),
                    AllowChildrenResourceTypes = table.Column<bool>(nullable: false),
                    AllowJobTypes = table.Column<bool>(nullable: false),
                    AllowParentResourceTypes = table.Column<bool>(nullable: false),
                    CreationTime = table.Column<DateTime>(nullable: false),
                    CreatorUser = table.Column<string>(nullable: true),
                    HasBaseOfOperation = table.Column<bool>(nullable: false),
                    HasSiteLocation = table.Column<bool>(nullable: false),
                    IsBillable = table.Column<bool>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    LastModificationTime = table.Column<DateTime>(nullable: true),
                    ModifierUser = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    TenantId = table.Column<int>(nullable: false),
                    ValidFrom = table.Column<DateTime>(nullable: true),
                    ValidUntil = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_vResourceType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "vResource",
                schema: "VektorResources",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AditionalFields = table.Column<string>(nullable: true),
                    BaseOfOperation = table.Column<bool>(nullable: false),
                    CreationTime = table.Column<DateTime>(nullable: false),
                    CreatorUser = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    Identifier = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    LastLocation = table.Column<string>(nullable: true),
                    LastModificationTime = table.Column<DateTime>(nullable: true),
                    LastState = table.Column<byte>(nullable: false),
                    ModifierUser = table.Column<string>(nullable: true),
                    TenantId = table.Column<int>(nullable: false),
                    ValidFrom = table.Column<DateTime>(nullable: true),
                    ValidUntil = table.Column<DateTime>(nullable: true),
                    vResourceTypeId = table.Column<long>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_vResource", x => x.Id);
                    table.ForeignKey(
                        name: "FK_vResource_vResourceType_vResourceTypeId",
                        column: x => x.vResourceTypeId,
                        principalSchema: "VektorResources",
                        principalTable: "vResourceType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_vResource_vResourceTypeId",
                schema: "VektorResources",
                table: "vResource",
                column: "vResourceTypeId");
        }
    }
}
