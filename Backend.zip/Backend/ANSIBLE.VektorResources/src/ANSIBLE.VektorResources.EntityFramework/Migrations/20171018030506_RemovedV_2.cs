﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace ANSIBLE.VektorResources.EntityFramework.Migrations
{
    public partial class RemovedV_2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Resource_ResourceType_VResourceTypeId",
                schema: "VektorResources",
                table: "Resource");

            migrationBuilder.DropIndex(
                name: "IX_Resource_VResourceTypeId",
                schema: "VektorResources",
                table: "Resource");

            migrationBuilder.DropColumn(
                name: "VResourceTypeId",
                schema: "VektorResources",
                table: "Resource");

            migrationBuilder.AddColumn<long>(
                name: "ResourceTypeId",
                schema: "VektorResources",
                table: "Resource",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.CreateIndex(
                name: "IX_Resource_ResourceTypeId",
                schema: "VektorResources",
                table: "Resource",
                column: "ResourceTypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Resource_ResourceType_ResourceTypeId",
                schema: "VektorResources",
                table: "Resource",
                column: "ResourceTypeId",
                principalSchema: "VektorResources",
                principalTable: "ResourceType",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Resource_ResourceType_ResourceTypeId",
                schema: "VektorResources",
                table: "Resource");

            migrationBuilder.DropIndex(
                name: "IX_Resource_ResourceTypeId",
                schema: "VektorResources",
                table: "Resource");

            migrationBuilder.DropColumn(
                name: "ResourceTypeId",
                schema: "VektorResources",
                table: "Resource");

            migrationBuilder.AddColumn<long>(
                name: "VResourceTypeId",
                schema: "VektorResources",
                table: "Resource",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.CreateIndex(
                name: "IX_Resource_VResourceTypeId",
                schema: "VektorResources",
                table: "Resource",
                column: "VResourceTypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Resource_ResourceType_VResourceTypeId",
                schema: "VektorResources",
                table: "Resource",
                column: "VResourceTypeId",
                principalSchema: "VektorResources",
                principalTable: "ResourceType",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
