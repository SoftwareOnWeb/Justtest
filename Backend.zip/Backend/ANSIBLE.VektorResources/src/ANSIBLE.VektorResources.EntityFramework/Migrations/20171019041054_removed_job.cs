﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace ANSIBLE.VektorResources.EntityFramework.Migrations
{
    public partial class removed_job : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Job",
                schema: "VektorResources");

            migrationBuilder.DropTable(
                name: "JobType",
                schema: "VektorResources");

            migrationBuilder.AlterColumn<string>(
                name: "BaseOfOperation",
                schema: "VektorResources",
                table: "Resource",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "BaseOfOperation",
                schema: "VektorResources",
                table: "Resource",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "JobType",
                schema: "VektorResources",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AditionalFields = table.Column<string>(nullable: true),
                    AllowChildrenTypes = table.Column<bool>(nullable: false),
                    AllowParentTypes = table.Column<bool>(nullable: false),
                    AllowResourcesTypes = table.Column<bool>(nullable: false),
                    CreationTime = table.Column<DateTime>(nullable: false),
                    CreatorUser = table.Column<string>(nullable: true),
                    HasCustomer = table.Column<bool>(nullable: false),
                    HasFinishByTime = table.Column<bool>(nullable: false),
                    HasSiteLocation = table.Column<bool>(nullable: false),
                    HasStartByTime = table.Column<bool>(nullable: false),
                    IsBillable = table.Column<bool>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false),
                    LastModificationTime = table.Column<DateTime>(nullable: true),
                    ModifierUser = table.Column<string>(nullable: true),
                    Name = table.Column<string>(nullable: true),
                    TenantId = table.Column<int>(nullable: false),
                    ValidFrom = table.Column<DateTime>(nullable: true),
                    ValidUntil = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JobType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Job",
                schema: "VektorResources",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    AditionalFields = table.Column<string>(nullable: true),
                    CreationTime = table.Column<DateTime>(nullable: false),
                    CreatorUser = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    Identifier = table.Column<string>(nullable: true),
                    IsDeleted = table.Column<bool>(nullable: false),
                    JobTypeId = table.Column<long>(nullable: true),
                    LastModificationTime = table.Column<DateTime>(nullable: true),
                    LastState = table.Column<byte>(nullable: false),
                    ModifierUser = table.Column<string>(nullable: true),
                    Priority = table.Column<byte>(nullable: false),
                    Reporter = table.Column<string>(nullable: true),
                    Resolution = table.Column<byte>(nullable: false),
                    Summary = table.Column<string>(nullable: true),
                    TenantId = table.Column<int>(nullable: false),
                    ValidFrom = table.Column<DateTime>(nullable: true),
                    ValidUntil = table.Column<DateTime>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Job", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Job_JobType_JobTypeId",
                        column: x => x.JobTypeId,
                        principalSchema: "VektorResources",
                        principalTable: "JobType",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Job_JobTypeId",
                schema: "VektorResources",
                table: "Job",
                column: "JobTypeId");
        }
    }
}
