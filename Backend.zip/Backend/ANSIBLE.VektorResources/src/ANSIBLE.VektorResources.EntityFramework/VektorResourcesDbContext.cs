﻿using Abp.Domain.Repositories;
using ANSIBLE.ComponentBase.EntityFrameworkCore;
using ANSIBLE.VektorResources.DomainEntity;
using ANSIBLE.VektorResources.EntityFrameworkCore.Repositories;
using Microsoft.EntityFrameworkCore;

namespace ANSIBLE.VektorResources.EntityFramework
{
    [AutoRepositoryTypes(
        typeof(IRepository<>),
        typeof(IRepository<,>),
        typeof(VektorResourcesRepositoryBase<>),
        typeof(VektorResourcesRepositoryBase<,>)
    )]
    public class VektorResourcesDbContext : ComponentBaseDbContext<VektorResourcesDbContext>
    {
        /* Define an IDbSet for each entity of the application */
        public DbSet<Resource> Resources { get; set; }
        public DbSet<ResourceType> ResourceTypes { get; set; }
        public VektorResourcesDbContext(DbContextOptions<VektorResourcesDbContext> options)
            : base(options)
        {
        }
    }
}
