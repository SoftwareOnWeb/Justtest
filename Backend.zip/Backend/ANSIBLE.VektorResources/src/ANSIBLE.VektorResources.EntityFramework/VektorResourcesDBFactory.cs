﻿using ANSIBLE.ComponentBase.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace ANSIBLE.VektorResources.EntityFramework
{
    class VektorResourcesDBFactory : ComponentBaseDbContextFactory<VektorResourcesDbContext>
    {
        public override VektorResourcesDbContext CreateInstance(DbContextOptions<VektorResourcesDbContext> options)
        {
            return new VektorResourcesDbContext(options);
        }
    }
}
