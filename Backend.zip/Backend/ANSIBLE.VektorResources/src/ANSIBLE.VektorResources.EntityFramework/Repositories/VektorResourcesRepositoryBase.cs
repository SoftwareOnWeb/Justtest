﻿using Abp.Domain.Entities;
using Abp.EntityFrameworkCore;
using Abp.EntityFrameworkCore.Repositories;
using ANSIBLE.ComponentBase.EntityFrameworkCore.Repositories;
using ANSIBLE.VektorResources.EntityFramework;

namespace ANSIBLE.VektorResources.EntityFrameworkCore.Repositories
{
    /// <summary>
    /// Base class for custom repositories of the application.
    /// </summary>
    /// <typeparam name="TEntity">Entity type</typeparam>
    /// <typeparam name="TPrimaryKey">Primary key type of the entity</typeparam>
    public class VektorResourcesRepositoryBase<TEntity, TPrimaryKey> :
        ComponentBaseRepositoryBase<VektorResourcesDbContext, TEntity, TPrimaryKey> 
        where TEntity : class, IEntity<TPrimaryKey>
    {
        public VektorResourcesRepositoryBase(IDbContextProvider<VektorResourcesDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        //add your common methods for all repositories
    }

    /// <summary>
    /// Base class for custom repositories of the application.
    /// This is a shortcut of <see cref="JobsRepositoryBase{TEntity,TPrimaryKey}"/> for <see cref="int"/> primary key.
    /// </summary>
    /// <typeparam name="TEntity">Entity type</typeparam>
    public abstract class VektorResourcesRepositoryBase<TEntity> : VektorResourcesRepositoryBase<TEntity, long>
        where TEntity : class, IEntity<long> 
    {
        public VektorResourcesRepositoryBase(IDbContextProvider<VektorResourcesDbContext> dbContextProvider)
            : base(dbContextProvider)
        {

        }

        //do not add any method here, add to the class above (since this inherits it)!!!
    }
}
