//using ANSIBLE.ComponentBase.Controllers;
using Microsoft.AspNetCore.Antiforgery;

namespace ANSIBLE.ComponentBase.Web.Host.Controllers
{
    //public class AntiForgeryController : ComponentControllerBase
    //{
    //    private readonly IAntiforgery _antiforgery;

    //    public AntiForgeryController(IAntiforgery antiforgery)
    //    {
    //        _antiforgery = antiforgery;
    //    }

    //    public void GetToken()
    //    {
    //        _antiforgery.SetCookieTokenAndHeader(HttpContext);
    //    }
    //}
}