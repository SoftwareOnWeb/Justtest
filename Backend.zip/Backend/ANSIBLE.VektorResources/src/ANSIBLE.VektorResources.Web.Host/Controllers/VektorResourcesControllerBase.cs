using Abp.AspNetCore.Mvc.Controllers;
using Abp.IdentityFramework;
using Microsoft.AspNetCore.Identity;

namespace ANSIBLE.ComponentBase.Web.Host.Controllers
{
    public abstract class VektorResourcesControllerBase : AbpController
    {
        protected VektorResourcesControllerBase()
        {
            LocalizationSourceName = ComponentBaseConsts.LocalizationSourceName;
        }

        protected void CheckErrors(IdentityResult identityResult)
        {
            identityResult.CheckErrors(LocalizationManager);
        }
    }
}