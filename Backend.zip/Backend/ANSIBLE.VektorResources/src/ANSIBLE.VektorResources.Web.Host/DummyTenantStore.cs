﻿using Abp.MultiTenancy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ANSIBLE.VektorResources.Web.Host
{
    public class DummyTenantStore : ITenantStore
    {
        public TenantInfo Find(int tenantId)
        {
            return new TenantInfo(tenantId, tenantId.ToString());
        }

        public TenantInfo Find(string tenancyName)
        {
            return new TenantInfo(int.Parse(tenancyName), tenancyName);
        }
    }
}
