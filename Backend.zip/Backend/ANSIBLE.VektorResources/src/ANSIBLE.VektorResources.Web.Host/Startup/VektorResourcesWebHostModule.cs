﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using ANSIBLE.ComponentBase.Configuration;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using ANSIBLE.VektorResources.Application;
using Abp.AspNetCore.Configuration;
using ANSIBLE.VektorResources.EntityFramework;
using Abp.AspNetCore.MultiTenancy;
using ANSIBLE.VektorResources.Web.Host;
using Abp.Dependency;
using Abp.MultiTenancy;
using Abp.Configuration.Startup;
using ANSIBLE.ComponentBase.Web.Host.Configuration;
using Abp.AspNetCore;

namespace ANSIBLE.ComponentBase.Web.Host.Startup
{
    [DependsOn(
        typeof(AbpAspNetCoreModule),
        typeof(VektorResourcesApplicationModule))]
    public class VektorResourcesWebHostModule: AbpModule
    {
        private readonly IHostingEnvironment _env;
        private readonly IConfigurationRoot _appConfiguration;

        public VektorResourcesWebHostModule(IHostingEnvironment env)
        {
            _env = env;
            _appConfiguration = env.GetAppConfiguration();
        }
        public override void PreInitialize()
        {
            base.PreInitialize();
            //Configuration.MultiTenancy.Resolvers.Add<MyHttpHeaderTenantResolveContributor>();
            Configuration.DefaultNameOrConnectionString = _appConfiguration.GetConnectionString(
                typeof(VektorResourcesDbContext).FullName
            );

            Configuration.Modules.AbpAspNetCore()
                    .CreateControllersForAppServices(
                        typeof(VektorResourcesApplicationModule).GetAssembly());
            Configuration.ReplaceService<ITenantStore, DummyTenantStore>(DependencyLifeStyle.Transient);

        }
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(VektorResourcesWebHostModule).GetAssembly());
        }
    }
}
